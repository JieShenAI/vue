<template>
  <Count />
</template>

<script>
import Count from "@/components/Count";
export default {
  components: {
    Count,
  },
};
</script>

<style>
</style>